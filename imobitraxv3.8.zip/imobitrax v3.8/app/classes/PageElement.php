<?php
//加密方式:ioncube 
//此程序由【PHP解密】http://www.phpjiemi.com/ (VIP会员功能）在线逆向还原，QQ：2436152386
//会员:jianmo_o@163.com 您好,破解:ioncube加密,本次扣金币:1个,金币余额:6个,感谢您的支持. 
?>
<?php  class PageElement 
{
	public static function topTemplate($titleTag = "Mobile Tracker", $calender = false, $sub = false, $onLoad = NULL, $devTest = false) 
	{
		$loggedIn = (isset($_SESSION["iMobi_sessionTime"]) && isset($_SESSION["iMobi_sessionId"]) ? true : false);
		$iMobiTraxCurrent = false;
		$availableImobiVersion = (isset($_SESSION["imobi_data"]["imVersion"]) ? $_SESSION["imobi_data"]["imVersion"] : "");
		$availableImobiVersionFloat = (double) trim(preg_replace("/[^0-9.]/", "", $availableImobiVersion));
		$currentImobiVersion = (double) trim(preg_replace("/[^0-9.]/", "", IMOBI_VERSION));
		if( $availableImobiVersionFloat <= $currentImobiVersion ) 
		{
			$iMobiTraxCurrent = true;
		}
		$status = (stripos(IMOBI_VERSION, "beta") ? "Beta" : "Current");
		if( $currentImobiVersion == $availableImobiVersionFloat && $status == "Beta" && stripos($availableImobiVersion, "Beta") === false ) 
		{
			$iMobiTraxCurrent = false;
			$currentImobiVersion = (string) $currentImobiVersion . " " . $status;
			$availableImobiVersion = (string) $availableImobiVersion . " Stable";
		}
		$onLoad = ($onLoad ? " onload=\"" . $onLoad . "\"" : NULL);
		$campaigns = $campaign = $groups = $networks = $sources = $subids = $stats = $reports = $filters = $logs = "normal";
		$page = "all";
		$currentPage = $_SERVER["PHP_SELF"];
		switch( true ) 
		{
			case stripos($currentPage, "campaigns.php"): $campaigns = "active";
			break;
			case stripos($currentPage, "campaign.php"): $campaign = "active";
			break;
			case stripos($currentPage, "groups.php"): $groups = "active";
			break;
			case stripos($currentPage, "networks.php"): $networks = "active";
			break;
			case stripos($currentPage, "sources.php"): $sources = "active";
			break;
			case stripos($currentPage, "subids.php"): $subids = "active";
			break;
			case stripos($currentPage, "stats.php"): $stats = "active";
			break;
			case stripos($currentPage, "report.php"): $reports = "active";
			break;
			case stripos($currentPage, "filters.php"): $filters = "active";
			$page = "filters";
			break;
			case stripos($currentPage, "log.php"): $logs = "active";
			break;
		}
		echo "<!DOCTYPE html>\r\n<html>\r\n\r\n<head>\r\n  <meta charset=\"utf-8\" />\r\n  <meta name=\"robots\" content=\"noindex, nofollow, noarchive, nosnippet\" />\r\n  <!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame -->\r\n  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\" />\r\n  <title>";
		echo $titleTag;
		echo "</title>\r\n  <link rel=\"stylesheet\" href=\"style.css\" type=\"text/css\" />\r\n  <link rel=\"stylesheet\" href=\"../app/plugins/colorbox/colorbox.css\" type=\"text/css\" />\r\n  <script type=\"text/javascript\" src=\"";
		echo HTTP_BASE;
		echo "://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js\"></script>\r\n  <script type=\"text/javascript\" src=\"";
		echo "../app/plugins/jquery.tools.min.js\"></script>\r\n <script src=\"../app/plugins/colorbox/jquery.colorbox-min.js\"></script>\r\n   <script type=\"text/javascript\" src=\"../app/plugins/calendar/calendar.js\"></script>\r\n  <script type=\"text/javascript\" src=\"js.js\"></script>\r\n  <script type=\"text/javascript\" src=\"ajax/ajax.js\"></script>\r\n  <script type=\"text/javascript\">\r\n    \$(document).ready(loadPage);\r\n\tfunction loadPage() {\r\n        loadPopUps('";
		echo $page;
		echo "');\r\n\t\tdiableRightClick();\r\n        getTokens();\r\n\t\t\$(\"img[rel]\").overlay({mask: '#000'});\r\n\t\t\$(\"a[rel]\").overlay({mask: '#000'});\r\n\t}\r\n  </script>\r\n</head>\r\n\r\n<body";
		echo $onLoad;
		echo ">\r\n\r\n  <div id=\"content\">\r\n    <div id=\"header\">\r\n    \t<img src=\"../images/logo.jpg\" class=\"logo\" width=\"188\" height=\"60\" alt=\"iMobiTrax\">\r\n        <div class=\"menu\">\r\n          <p class=\"menu\"><a href=\"http://www.imobitrax.com/users/login\" target=\"_blank\">My Account</a></p>\r\n          <p class=\"menu\"><a href=\"settings.php\">Settings</a></p>\r\n          <p class=\"menu\"><a href=\"http://www.imobitrax.com/support/index.php?/Knowledgebase/List\" target=\"_blank\">Knowledge Base</a></p>\r\n          <p class=\"menu\"><a href=\"http://www.imobitrax.com/users/content/f/id/7/\" target=\"_blank\">User Guide</a></p>\r\n";
		if( $loggedIn ) 
		{
			echo "          <p class=\"menu\"><a href=\"logout.php\">Logout</a></p>\r\n";
		}
		echo "        </div>\r\n";
		if( $loggedIn ) 
		{
			echo "        <div class=\"data\">\r\n            <p class=\"data\">";
			if( $iMobiTraxCurrent ) 
			{
				echo "iMobiTrax v" . $currentImobiVersion . " - " . $status;
			}
			else 
			{
				echo "<a href=\"" . IMOBI_DOWNLOAD_LINK . "\" target=\"_blank\">iMobiTrax v" . $currentImobiVersion . " - Download v" . $availableImobiVersion . "</a>";
			}
			echo "</p>\r\n        </div>\r\n";
		}
		echo "    </div>\r\n    <div id=\"menu\">\r\n        <div>\r\n            <a name=\"1\"></a>\r\n            <ul>\r\n                <li class=\"";
		echo $campaigns;
		echo "\"><a href=\"campaigns.php\">Campaigns</a></li>\r\n                <li class=\"";
		echo $campaign;
		echo "\"><a href=\"campaign.php\">Add Campaign</a></li>\r\n                <li class=\"";
		echo $groups;
		echo "\"><a href=\"groups.php\">Groups</a></li>\r\n                <li class=\"";
		echo $networks;
		echo "\"><a href=\"networks.php\">Affiliate Networks</a></li>\r\n                <li class=\"";
		echo $sources;
		echo "\"><a href=\"sources.php\">Traffic Sources</a></li>\r\n                <li class=\"";
		echo $subids;
		echo "\"><a href=\"subids.php\">Subid Update</a></li>\r\n                <li class=\"";
		echo $stats;
		echo "\"><a href=\"stats.php\">Stats</a></li>\r\n                <li class=\"";
		echo $reports;
		echo "\"><a href=\"custom-report.php\">Reports</a></li>\r\n                <li class=\"";
		echo $filters;
		echo "\"><a href=\"filters.php\">Filters</a></li>\r\n                <li class=\"";
		echo $logs;
		echo "\"><a href=\"conversion-log.php\">Logs</a></li>\r\n            </ul>\r\n        </div>\r\n    </div>\r\n\r\n    <div id=\"main\">\r\n\t";
	}
	public static function topTemplateLogin($titleTag = "iMobiTrax Mobile Tracker") 
	{
		echo "<!DOCTYPE html>\r\n<html>\r\n\r\n<head>\r\n  <meta charset=\"utf-8\" />\r\n  <meta name=\"robots\" content=\"noindex, nofollow, noarchive, nosnippet\" />\r\n  <!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame -->\r\n  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\" />\r\n  <title>";
		echo $titleTag;
		echo "</title>\r\n  <link rel=\"stylesheet\" href=\"style.css\" type=\"text/css\" />\r\n  <link rel=\"stylesheet\" href=\"../app/plugins/colorbox/colorbox.css\" type=\"text/css\" />\r\n  <script type=\"text/javascript\" src=\"";
		echo HTTP_BASE;
		echo "://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js\"></script>\r\n  <script type=\"text/javascript\" src=\"";
		echo "../app/plugins/jquery.tools.min.js\"></script>\r\n  <script type=\"text/javascript\" src=\"../app/plugins/colorbox/jquery.colorbox-min.js\"></script>\r\n  <script type=\"text/javascript\" src=\"js.js\"></script>\r\n  <script type=\"text/javascript\" src=\"ajax/ajax.js\"></script>\r\n  <script type=\"text/javascript\">\r\n    \$(document).ready(loadPage);\r\n    function loadPage() {\r\n        attachColorbox();\r\n    }\r\n  </script>\r\n</head>\r\n\r\n<body>\r\n\r\n  <div id=\"content\">\r\n    <div id=\"header\">\r\n        <img src=\"../images/logo.jpg\" class=\"logo\" width=\"188\" height=\"60\" alt=\"iMobiTrax\">\r\n    </div>\r\n\r\n    <div id=\"main\">\r\n";
	}
	public static function bottomTemplate() 
	{
		echo "\t\t</div>\r\n\t\t<div id=\"footer\">\r\n\t\t\t<img src=\"../images/logo_small.jpg\" width=\"94\" height=\"30\" alt=\"iMobiTrax\">\r\n\t\t\t<p>&copy; 2013 Mobile Tracking Software – iMobiTrax, LLC - Patent Pending</p>\r\n\t\t</div>\r\n\t</div>\r\n\r\n</body>\r\n</html>\r\n";
	}
	public static function popUpTemplate($titleTag = "iMobiTrax ReadMe", $content) 
	{
		echo "<!DOCTYPE html>\r\n<html>\r\n\r\n<head>\r\n  <meta charset=\"utf-8\" />\r\n  <meta name=\"robots\" content=\"noindex, nofollow, noarchive, nosnippet\">\r\n  <link rel=\"stylesheet\" href=\"../select.css\" type=\"text/css\">\r\n  <title>";
		echo $titleTag;
		echo "</title>\r\n  <script type=\"text/javascript\" src=\"";
		echo HTTP_BASE;
		echo "://ajax.googleapis.com/ajax/libs/jquery/1.8/jquery.min.js\"></script>\r\n  <script type=\"text/javascript\" src=\"../ajax/ajax.js\"></script>\r\n</head>\r\n\r\n<body class=\"iframe\">\r\n\r\n";
		echo $content;
		echo "\r\n</body>\r\n\r\n</html>\r\n";
	}
	public static function statSubLinks(array $queryStrValues, $currentPage) 
	{
		if( $queryStrValues["campaign"] ) 
		{
			$queryS = "?campaign=" . $queryStrValues["campaign"] . "&status=" . $queryStrValues["status"] . "&group=" . $queryStrValues["group"] . "&source=" . $queryStrValues["source"];
			$statslink = "stats.php" . $queryS;
			$partinglink = "part-stats.php" . $queryS;
			$ruleslink = "filter-stats.php" . $queryS;
			switch( $currentPage ) 
			{
				case "stats": echo "<p class=\"submenu\"><span>Campaign Stats</span><span><a href=\"" . $partinglink . "\">Week/Day Parting</a></span><a href=\"" . $ruleslink . "\">Traffic Blocking/Filter Stats</a></span></p>";
				break;
				case "part-stats": echo "<p class=\"submenu\"><span><a href=\"" . $statslink . "\">Campaign Stats</a></span><span>Week/Day Parting</span><a href=\"" . $ruleslink . "\">Traffic Blocking/Filter Stats</a></span></p>";
				break;
				case "rule-stats": echo "<p class=\"submenu\"><span><a href=\"" . $statslink . "\">Campaign Stats</a></span><span><a href=\"" . $partinglink . "\">Week/Day Parting</a></span>Traffic Blocking/Filter Stats</span></p> ";
				break;
			}
		}
	}
	public static function logSubLinks(array $queryStrValues, $currentPage) 
	{
		$botLink = "bot-log.php";
		$pbLink = "postback-log.php";
		$cvrLink = "conversion-log.php";
		$pd3Log = "3rd-party-postback-log.php";
		if( $queryStrValues["campaign"] || $queryStrValues["status"] != 0 || 0 <= $queryStrValues["group"] || 0 <= $queryStrValues["source"] ) 
		{
			$queryS = "?campaign=" . $queryStrValues["campaign"] . "&status=" . $queryStrValues["status"] . "&group=" . $queryStrValues["group"] . "&source=" . $queryStrValues["source"];
			$botLink = "bot-log.php" . $queryS;
			$pbLink = "postback-log.php" . $queryS;
			$cvrLink = "conversion-log.php" . $queryS;
			$pd3Log = "3rd-party-postback-log.php" . $queryS;
		}
		switch( $currentPage ) 
		{
			case "conversion": echo "<p class=\"submenu\"><span>Conversion Log</span><span><a href=\"" . $pbLink . "\">Postback Log</a></span><span><a href=\"" . $pd3Log . "\">3rd-Party Postback Log</a></span><a href=\"" . $botLink . "\">Robots Log</a></span></p>";
			break;
			case "postback": echo "<p class=\"submenu\"><span><a href=\"" . $cvrLink . "\">Conversion Log</a></span><span>Postback Log</span><span><a href=\"" . $pd3Log . "\">3rd-Party Postback Log</a></span><a href=\"" . $botLink . "\">Robots Log</a></span></p>";
			break;
			case "bot": echo "<p class=\"submenu\"><span><a href=\"" . $cvrLink . "\">Conversion Log</a></span><span><a href=\"" . $pbLink . "\">Postback Log</a></span><span><a href=\"" . $pd3Log . "\">3rd-Party Postback Log</a></span>Robots Log</span></p> ";
			break;
			case "thirdParty": echo "<p class=\"submenu\"><span><a href=\"" . $cvrLink . "\">Conversion Log</a></span><span><a href=\"" . $pbLink . "\">Postback Log</a></span><span>3rd-Party Postback Log</span><a href=\"" . $botLink . "\">Robots Log</a></span></p> ";
			break;
		}
	}
	public static function selectCampaignButton($onClick = "selectCampaign()") 
	{
		echo "\t\t<div class=\"refresh\">\r\n\t\t\t<ul class=\"refresh\">\r\n\t\t\t\t<li><a href=\"#\" onClick=\"";
		echo $onClick;
		echo ";\">Select</a></li>\r\n\t\t\t</ul>     \r\n\t\t</div>\r\n\t\t";
	}
	public static function refreshButton() 
	{
		$self = $_SERVER["REQUEST_URI"];
		$self = str_ireplace("?refresh=true", "", $self);
		$self = str_ireplace("&refresh=true", "", $self);
		if( parse_url($self, PHP_URL_QUERY) ) 
		{
			$self = $self . "&refresh=true";
		}
		else 
		{
			$self = $self . "?refresh=true";
		}
		echo "\t\t<div class=\"refresh\">\r\n\t\t\t<ul class=\"refresh\">\r\n\t\t\t\t<li><a href=\"";
		echo $self;
		echo "\">Refresh</a></li>\r\n\t\t\t</ul>     \r\n\t\t</div>\r\n\t\t";
	}
	public static function csvDownloadLink($csvOnClick, $nReturned, $nPages, $showAll = false) 
	{
		if( $nReturned && 1 < $nPages && !$showAll ) 
		{
			$csvOnClick1 = $csvOnClick . "&all=1";
			echo "<p class=\"csvLink\" style=\"margin-top:-10px\">Download CSV > <a href=\"#\" onclick=\"window.location.href='" . $csvOnClick . "'; return false\">This Page</a> / <a href=\"#\" onclick=\"window.location.href='" . $csvOnClick1 . "'; return false\">All Pages</a></p>";
		}
		else 
		{
			echo "<p class=\"csvLink\" style=\"margin-top:-10px\"><a href=\"#\" onclick=\"window.location.href='" . $csvOnClick . "'; return false\">Download CSV</a></p>";
		}
	}
}
?>